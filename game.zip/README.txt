==== BLOXGAME 2.0 ====
"The Virtual-Bricks Game"
Youre Reading the BLOXGAME 2.0 README!
Congratulations on Selecting BloxGame as your Virtual Bricks Tool! BloxGame is Packed of Epic Features
to Play and Build Games with Bricks
With BLOXGAME you Get
The Tool to Build Epic Games
The tool to play epic games
This File
Join our AOL Instant Messenger to Chat with other ppl about BLOXGAME!
Link: https://discord.gg/4y3PWnncQF
Invite Code: 4y3PWnncQF
Enjoy This!
== Credits ==
Programming: PressTpro
Assets: PressTpro
Distribution: PressTpro
Amazing Support: PressTpro
People Involved (cause yes): PressTpro
== CONTACT == 
if you Want to Contact Me you can Contact me as
PressTpro#0260 in AIM
== HOW TO RUN == 
Open Windows File Explorer or MacOS finder
Extract the file then open BloxGame 2.0.html 
It will Open Internet Explorer or Internet Explorer:mac
Enjoy the Game!
== CONTROLS == 
Move: WASD Keys and Arrow Keys
Accept: Space
Decline: ENTER
if youre using a Nokia 3310 Use the Touch Keys and the Buttons to Move
== COPYRIGHT
Copyright (c) 1990 BloxGame Team
BloxGame is Not Affilated with
ROBLOX
Lego 
Mega
Nintendo
Minecraft 3D
etc
== HOW TO HOST ==
Before Host a Server for Multiplayer, Add the Following adress to the IP Adress
presstpro.github.io/blxsrvhst/MAPNAME/PLAYERNAME/SERVERPORT/
Change MAPNAME to a Name of a Map Included in the Game
Change PLAYERNAME of the Hoster of the Server
Change SERVERPORT to the Port Number of your Server
Once Loaded, Get a API Key of BloxGame API in presstpro.github.io/blxgmeapi
Install BloxGame API using NodeJS
>> npm install blxgame-api
blxgame.mp.host(APIKEY)
blxgame.api.connect(presstpro.github.io/blxsrvhst/MAPNAME/PLAYERNAME/SERVERPORT).(APIKEY).link
blxgame.api.connected.action = start <<
Then Go to BloxGame in your Server, Send the Following Link to Allow People to Play
presstpro.github.io/blxsrvcnt/APIKEY
A Input will ask you to Insert Username, once Completed Click OK, Select Join as Guest if you want to play in guest mode
Select a Map and Play!



















